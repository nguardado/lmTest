create trigger update_accounts
	after insert
	on lifebank.tra_transactions
	for each row
	execute procedure lifebank.udpate_transactions_inserts();