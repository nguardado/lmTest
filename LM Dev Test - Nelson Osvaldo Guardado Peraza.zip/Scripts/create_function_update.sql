create or replace function lifebank.udpate_transactions_inserts()
	returns trigger
	language 'plpgsql'
	as $BODY$
declare
	actual_amount numeric;
	actual_other_value_amount numeric;
begin
	select acc_amount into actual_amount
	from lifebank.acc_account
	where acc_code_account = new.tra_account_code;		

	if actual_amount >= new.tra_amount then			
			if (new.tra_transaction_type = 'TCP001' or new.tra_transaction_type = 'PTC001') then 
				update lifebank.acc_account 
				set acc_amount = (actual_amount - new.tra_amount), acc_mod_date = now()
				where acc_code_account = new.tra_account_code;
				
				select acc_amount into actual_other_value_amount
				from lifebank.acc_account 
				where acc_code_account = new.tra_account_transfer;
				
				update lifebank.acc_account
				set acc_amount = (actual_other_value_amount + new.tra_amount), acc_mod_date = now()			
				where acc_code_account = new.tra_account_transfer;
			
			elseif (new.tra_transaction_type = 'PTP001' or new.tra_transaction_type = 'PTC001') then
				update lifebank.acc_account 
				set acc_amount = (actual_amount - new.tra_amount), acc_mod_date = now()
				where acc_code_account = new.tra_account_code;
				
				select cc_available_amount into actual_other_value_amount
				from lifebank.cc_credit_card_client 
				where cc_credit_card_number = new.tra_credit_card_number;
				
				update lifebank.cc_credit_card_client
				set cc_available_amount = (actual_other_value_amount + new.tra_amount), cc_mod_date = now()
				where cc_credit_card_number = new.tra_credit_card_number;
		
			elseif (new.tra_transaction_type = 'PPP001' or new.tra_transaction_type = 'PPT001') then
				update lifebank.acc_account 
				set acc_amount = (actual_amount - new.tra_amount), acc_mod_date = now()
				where acc_code_account = new.tra_account_code;
				
				select loa_loan_remaining_debt into actual_other_value_amount
				from lifebank.loa_loan_client
				where loa_loan_code = new.tra_loan_number;
				
				update lifebank.loa_loan_client
				set loa_loan_remaining_debt = (actual_other_value_amount - new.tra_amount), loa_mod_date = now()
				where loa_loan_code = new.tra_loan_number;			
			else
				return new;
				raise exception 'Operacion no encontrada';
		end if;
	return new;
	else 
		return new;
		raise exception 'Saldo insuficiente';						
	end if;
	end;
$BODY$

		