create schema lifebank;

create table lifebank.cli_client (
	cli_code varchar (25) not null,
	cli_name varchar (25) not null,
	cli_last_name varchar (25) not null,
	cli_email varchar (100) null,
	cli_document varchar(25) null,
	cli_birth_date timestamp not null,
	cli_status varchar(1) not null,
	constraint cli_client_pk primary key (cli_code)
)
with(oids = FALSE);

create table lifebank.usr_users (
	usr_user_code varchar(25) not null,
	usr_user varchar (25) not null,
	usr_password varchar (25) not null,
	usr_status varchar(1) not null,
	usr_createdate timestamp null default now(),
	usr_modified_date timestamp null,
	constraint usr_users_pk primary key (usr_user),
	constraint usr_users_fk foreign key (usr_user_code) references lifebank.cli_client(cli_code)
)
with(oids = FALSE);

create table lifebank.ben_beneficiaries(	
	ben_usr_code_ori varchar (25) not null,
	ben_usr_code_des varchar (25) not null,
	ben_name varchar(25) not null,
	ben_last_name varchar(25) not null,
	ben_status varchar(1) not null,
	ben_email varchar(25) not null,
	ben_acount_num varchar (8) not null,
	ben_credit_card varchar (8) null,
	ben_loan_code varchar (8) null,
	ben_account_type varchar (50) null,
	constraint ben_beneficiaries_pk primary key (ben_usr_code_ori, ben_usr_code_des),
	constraint ben_beneficiaries_ori_fk foreign key (ben_usr_code_ori) references lifebank.cli_client(cli_code),
	constraint ben_beneficiaries_des_fk foreign key (ben_usr_code_des) references lifebank.cli_client(cli_code)
)
with(oids = FALSE);

create table lifebank.tcue_type_account (
	tcue_code_type varchar (8) not null,
	tcue_name varchar (50) not null,
	tcue_status varchar(1) not null,
	tcue_description varchar (100) null,
	constraint tcue_type_account_pk primary key (tcue_code_type)
)
with(oids = FALSE);

create table lifebank.acc_account(
	acc_cli_code varchar(25) not null,	
	acc_code_account varchar (10) not null,
	acc_type_account varchar (8) not null,
	acc_amount numeric not null default 0.0,
	acc_status varchar(1) not null,
	acc_created_date timestamp not null default now(),
	acc_mod_date timestamp null,
	acc_close_date timestamp null,
	acc_description varchar(100) null,
	constraint acc_account_pk primary key (acc_code_account),
	constraint acc_type_account_fk foreign key (acc_type_account) references lifebank.tcue_type_account(tcue_code_type),
	constraint acc_cli_code_fk foreign key (acc_cli_code) references lifebank.cli_client (cli_code)		
)
with(oids = FALSE);

create table lifebank.tta_credit_card_type(
	tta_code_type varchar (8) not null,
	tta_name varchar(50) not null,
	tta_status varchar(1) not null,
	tta_limit numeric not null,
	tta_interes_rate numeric not null,	
	tta_description varchar(100) null,
	constraint tta_credit_card_pk primary key (tta_code_type)
)
with(oids = FALSE);

create table lifebank.cc_credit_card_client(
	cc_client_number varchar(25) not null,
	cc_credit_card_number varchar(16) not null,
	cc_code_type varchar(8) not null,
	cc_start_validity_date timestamp not null,
	cc_end_validity_date timestamp not null,
	cc_available_amount numeric not null,
	cc_limit numeric not null,	
	cc_montly_cut numeric not null,
	cc_interest_amount numeric not null,	
	cc_create_date timestamp not null default now(),
	cc_mod_date timestamp null,
	cc_close_date timestamp null,
	cc_credit_card_status varchar(1) not null,
	cc_description varchar(100) null,	
	constraint cc_credit_card_pk primary key (cc_credit_card_number),
	constraint cc_client_number_fk foreign key (cc_client_number) references lifebank.cli_client(cli_code),
	constraint cc_credit_card_type_fk foreign key (cc_code_type) references lifebank.tta_credit_card_type(tta_code_type)
)
with(oids = FALSE);

create table lifebank.tloa_loan_type(
	tloa_code_type varchar (8) not null,
	tloa_name varchar (50) not null,
	tloa_status varchar(1) not null,
	tloa_description varchar(100) null,
	tloa_interes_rate numeric not null,
	tloa_create_date timestamp not null default now(),
	tloa_mod_date timestamp null,
	constraint loa_loan_type primary key (tloa_code_type)
)
with(oids = FALSE);

create table lifebank.loa_loan_client(
	loa_client_number varchar(25) not null,
	loa_code_type varchar (8) not null,
	loa_loan_code varchar(10) not null,
	loa_loan_total_debt numeric not null,
	loa_loan_remaining_debt numeric not null,
	loa_loan_interest_amount numeric not null,
	loa_create_date timestamp not null default now(),
	loa_end_date timestamp not null,
	loa_mod_date timestamp null,	
	loa_close_date timestamp null,
	loa_description varchar(100) null,
	constraint loa_loan_client_pk primary key (loa_loan_code),
	constraint loa_client_number_fk foreign key (loa_client_number) references lifebank.cli_client(cli_code),
	constraint loa_type_loan_fk foreign key (loa_code_type) references lifebank.tloa_loan_type(tloa_code_type)
)
with(oids = FALSE);

create table lifebank.typ_transaction_type (
	typ_code varchar(8) not null,
	typ_name varchar(100) not null,
	typ_status varchar(1) not null,
	typ_description varchar(100) null,
	typ_create_date timestamp not null default now(),
	typ_mod_date timestamp null,
	constraint typ_transanction_pk primary key (typ_code)
)
with(oids = FALSE);

create table lifebank.tra_transactions (	
	tra_transaction_type varchar(8) not null,
	tra_client_code varchar(25) not null,
	tra_account_code varchar(10) not null,	
	tra_account_transfer varchar(10) null,
	tra_amount numeric not null,
	tra_credit_card_number varchar(16) null,
	tra_loan_number varchar(10) null,	
	tra_proceed_date timestamp null default now(),
	tra_register_date timestamp null default now(),
	tra_transaction_status varchar(1) not null,
	tra_status_description varchar(25) not null,	
	tra_transaction_description varchar(100) null,
	constraint tra_transactions_pk primary key (tra_transaction_type, tra_proceed_date),
	constraint tra_transaction_type_fk foreign key (tra_transaction_type) references lifebank.typ_transaction_type(typ_code),
	constraint tra_account_fk foreign key (tra_account_code) references lifebank.acc_account (acc_code_account),
	constraint tra_credit_card_fk foreign key (tra_credit_card_number) references lifebank.cc_credit_card_client (cc_credit_card_number),
	constraint tra_loan_number_fk foreign key (tra_loan_number) references lifebank.loa_loan_client (loa_loan_code)
)
with(oids = FALSE);
