package com.life.data.trapropia;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.life.entity.AccAccount;
import com.life.entity.TraTransactions;
import com.life.entity.TraTransactionsId;
import com.life.entity.TypTransactionType;
import com.life.pojo.transactions.ReqTransactionPojo;
import com.life.pojo.transactions.RespTransactionPojo;
import com.life.process.repository.TransCuentaPropiaRepository;

@Service("TransCuentaDataBase")
public class TransCuentaDataBase implements ITransCuentaPropiaData{
	private  TransCuentaPropiaRepository repo;
	private Logger log;
	
	@Value("${config.transaction-types.cuenta-propia}")
	String codeTransaction;
	
	@Value("${config.date-format}")
	String normalDate;
	
	public TransCuentaDataBase(TransCuentaPropiaRepository repo) {
		this.repo = repo;
		this.log = LoggerFactory.getLogger("com.lifebank.logger");
	}
	@Override
	public RespTransactionPojo transCuentaPropia(ReqTransactionPojo infoTrans, String clientCode) {		
		try {
		TypTransactionType tranType = new TypTransactionType();
		TraTransactionsId id = new TraTransactionsId();
		AccAccount account = new AccAccount();
		tranType.setTypCode(codeTransaction);
		account.setAccCodeAccount(infoTrans.getOrigingAccount());
		TraTransactions saveData = new TraTransactions();
		RespTransactionPojo respuesta = new RespTransactionPojo();		
		Calendar cal = Calendar.getInstance();
		Date date = cal.getTime();		
		TraTransactions transaction = new TraTransactions();			
		transaction.setTypTransactionType(tranType);
		transaction.setTraClientCode(clientCode);
		transaction.setAccAccount(account);
		id.setTraTransactionType(codeTransaction);
		id.setTraProceedDate(date);		
		transaction.setId(id);
		transaction.setTraAccountTransfer(infoTrans.getDestAccount());
		transaction.setTraAmount(BigDecimal.valueOf(infoTrans.getAmount()));				
		transaction.setTraTransactionStatus("P");
		transaction.setTraStatusDescription("Procesada");
		transaction.setTraTransactionDescription("Transferencia a cuentas propias");
		saveData = repo.save(transaction);
		
		respuesta.setTransactionCode(saveData.getId().toString());
		
		return respuesta;
		
		} catch (Exception e) {
			log.error("Error in save transaction dabatese: {} cashier {}",e.getMessage(), infoTrans.getOrigingAccount(), e);
			return new RespTransactionPojo();
		}		
	}

}
