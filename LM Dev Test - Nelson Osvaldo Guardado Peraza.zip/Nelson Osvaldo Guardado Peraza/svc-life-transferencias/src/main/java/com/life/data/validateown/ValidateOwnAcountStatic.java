package com.life.data.validateown;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.life.entity.AccAccount;
import com.life.entity.CliClient;
import com.life.pojo.transactions.ValidateAccountPojo;
import com.life.utils.ResponseCodes;

@Service("ValidateAccountStatic")
public class ValidateOwnAcountStatic implements IValidateOwnAccountData{
	private List<AccAccount> lstAccounts;
	private AccAccount ownAccount;
	private Map<String, List<AccAccount>> mapAccounts;
	private CliClient cliente = new CliClient();	
	
	public ValidateOwnAcountStatic() {
		lstAccounts = new ArrayList<>();
		mapAccounts = new HashMap<>();
		
		ownAccount  = new AccAccount();		
		ownAccount.setAccAmount(BigDecimal.valueOf(1500d));
		ownAccount.setAccCodeAccount("123456");	
		cliente.setCliCode("22553366");
		ownAccount.setCliClient(cliente);
		lstAccounts.add(ownAccount);
		mapAccounts.put("123456", lstAccounts);
		
		ownAccount  = new AccAccount();		
		ownAccount.setAccAmount(BigDecimal.valueOf(1500d));
		cliente.setCliCode("22553366");
		ownAccount.setCliClient(cliente);
		ownAccount.setAccCodeAccount("123457");
		lstAccounts.add(ownAccount);
		mapAccounts.put("123457", lstAccounts);
		
		ownAccount  = new AccAccount();		
		ownAccount.setAccAmount(BigDecimal.valueOf(1500d));
		cliente.setCliCode("22553377");
		ownAccount.setCliClient(cliente);
		ownAccount.setAccCodeAccount("123458");
		lstAccounts.add(ownAccount);
		mapAccounts.put("123458", lstAccounts);
	}
			
	@Override
	public ValidateAccountPojo validateOwnAccount(String accountOrg, String accountDest, Double amount) {
		boolean valAmount = false;
		boolean destAccount = false;
		ValidateAccountPojo validateAccount = new ValidateAccountPojo();		
		if(mapAccounts.containsKey(accountOrg)) {						
			Optional<AccAccount> amountval = mapAccounts.get(accountOrg)
					.stream()
					.filter(a->a.getAccCodeAccount().equals(accountOrg))
					.findFirst();
			if(amountval.isPresent()){
				if(amountval.get().getAccAmount().doubleValue() >= amount) {
					valAmount = true;
					validateAccount.setClientCode(amountval.get().getCliClient().getCliCode());					
				} else {
					validateAccount.setCode(ResponseCodes.NOENOUGH);
				}
						
			}
			if(valAmount) {
				Optional<AccAccount> existAccount = mapAccounts.get(accountDest)
						.stream()
						.filter(a->a.getCliClient().getCliCode().equals(validateAccount.getClientCode()))
						.findFirst();
				if(existAccount.isPresent())					
					destAccount = true;		
				} else {
					validateAccount.setCode(ResponseCodes.NOMATCH);
				}						
		}
		validateAccount.setStatus(valAmount && destAccount);		
		return validateAccount;
	}

}
