package com.life.process.repository;

import org.springframework.data.repository.CrudRepository;

import com.life.entity.TraTransactions;

public interface TransCuentaPropiaRepository extends CrudRepository<TraTransactions, String>{

}
