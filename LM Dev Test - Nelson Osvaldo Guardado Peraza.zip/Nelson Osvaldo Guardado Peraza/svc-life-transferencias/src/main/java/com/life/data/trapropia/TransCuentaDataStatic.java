package com.life.data.trapropia;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.life.pojo.transactions.ReqTransactionPojo;
import com.life.pojo.transactions.RespTransactionPojo;


@Service("TransPropiaStatic")
public class TransCuentaDataStatic implements ITransCuentaPropiaData{
	private RespTransactionPojo request = new RespTransactionPojo();	
	private Logger log;
	
	public TransCuentaDataStatic() {
		this.log =  LoggerFactory.getLogger("com.life.logger");		
	}
	@Override
	public RespTransactionPojo transCuentaPropia(ReqTransactionPojo infoTrans, String clientCode) {
		try {			
			request.setTransactionCode(String.valueOf(1552));
			return request;
		} catch (Exception e) {
			log.error("Error al guardar la transaccion");
			return request;
		}		
	}

}
