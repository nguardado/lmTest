package com.life.data.trapropia;

import com.life.pojo.transactions.ReqTransactionPojo;
import com.life.pojo.transactions.RespTransactionPojo;

public interface ITransCuentaPropiaData {
	public RespTransactionPojo transCuentaPropia(ReqTransactionPojo infoTrans, String clientCode);
}
