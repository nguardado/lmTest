package com.life.data.validateown;

import com.life.pojo.transactions.ValidateAccountPojo;

public interface IValidateOwnAccountData {
	public ValidateAccountPojo validateOwnAccount(String accountOrg, String accountDest, Double amount);
}
