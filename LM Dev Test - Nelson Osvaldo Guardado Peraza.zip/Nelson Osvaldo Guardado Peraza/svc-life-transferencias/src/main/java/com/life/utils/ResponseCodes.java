package com.life.utils;

public class ResponseCodes {
	public static final String SUCCESS="200";
	public static final String NOMATCH="404";
	public static final String NOENOUGH="409";
	public static final String PROCESSERROR = "500";
}
