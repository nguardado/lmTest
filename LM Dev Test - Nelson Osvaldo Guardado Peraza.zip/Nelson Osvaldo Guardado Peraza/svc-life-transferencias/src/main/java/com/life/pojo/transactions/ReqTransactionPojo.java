package com.life.pojo.transactions;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ReqTransactionPojo {
	private String origingAccount;
	private String destAccount;
	private Double amount;
}
