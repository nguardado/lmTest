package com.life.process.repository;

import org.springframework.data.repository.CrudRepository;

import com.life.entity.AccAccount;

public interface ValidateOwnAccountRepository extends CrudRepository<AccAccount, String>{	
}
