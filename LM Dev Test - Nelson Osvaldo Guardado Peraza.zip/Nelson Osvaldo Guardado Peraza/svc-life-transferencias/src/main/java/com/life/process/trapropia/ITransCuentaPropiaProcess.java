package com.life.process.trapropia;

import com.life.pojo.envelope.Envelope;
import com.life.pojo.envelope.Status;
import com.life.pojo.transactions.ReqTransactionPojo;
import com.life.pojo.transactions.RespTransactionPojo;

public interface ITransCuentaPropiaProcess {
	public Envelope<Status, RespTransactionPojo> saveTransCuentaPropia(ReqTransactionPojo value);
}
