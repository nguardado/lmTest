package com.life.utils;

public class ResponseMsg {
	public static final String SUCCESS="Success";
	public static final String NOMATCH="Cuenta propia no existente";
	public static final String NOENOUGH="No hay suficientes creditos";
	public static final String PROCESSERROR = "Se produjo un error en la transferencia";
	
}
