package com.life.data.validateown;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.life.entity.AccAccount;
import com.life.pojo.transactions.ValidateAccountPojo;
import com.life.process.repository.ValidateOwnAccountRepository;
import com.life.utils.ResponseCodes;

@Service("ValidateOwnAccountDataBase")
public class ValidateOwnAccountDataBase implements IValidateOwnAccountData{
	private ValidateOwnAccountRepository repo;
	private Logger log;	
	
	public ValidateOwnAccountDataBase(ValidateOwnAccountRepository repo) {
		this.repo = repo;
		this.log = LoggerFactory.getLogger("com.lifebank.logger");
	}

	@Override
	public ValidateAccountPojo validateOwnAccount(String accountOrg, String accountDest, Double amount) {
		boolean valAmount = false;
		boolean destAccount = false;
		ValidateAccountPojo validateAccount = new ValidateAccountPojo();
		
		Optional<AccAccount> amountval = repo.findById(accountOrg);
			if(amountval.isPresent()) {
				if(amountval.get().getAccAmount().doubleValue() >= amount) {
					valAmount = true;
					validateAccount.setClientCode(amountval.get().getCliClient().getCliCode());
				} else {
					validateAccount.setCode(ResponseCodes.NOENOUGH);
				}
			} else {
				log.error("Cuenta de cliente no encontrada {}", accountOrg);
			}
		
		if(valAmount) {
			Optional<AccAccount> existAccount = repo.findById(accountDest);
			if(existAccount.isPresent() && existAccount.get().getCliClient().getCliCode().equals(validateAccount.getClientCode())) { 
				destAccount = true;
				validateAccount.setCode(ResponseCodes.SUCCESS);
			}
			else 
				validateAccount.setCode(ResponseCodes.NOMATCH);	
		}			
		validateAccount.setStatus(valAmount && destAccount);		
		return validateAccount;
	}

}
