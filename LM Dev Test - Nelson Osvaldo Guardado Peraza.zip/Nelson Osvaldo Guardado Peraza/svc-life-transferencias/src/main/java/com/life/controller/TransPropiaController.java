package com.life.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.life.pojo.envelope.Envelope;
import com.life.pojo.envelope.Status;
import com.life.pojo.transactions.ReqTransactionPojo;
import com.life.pojo.transactions.RespTransactionPojo;
import com.life.process.trapropia.ITransCuentaPropiaProcess;
import com.life.process.trapropia.TransCuentaPropiaProcess;

@RestController
public class TransPropiaController {
	private ITransCuentaPropiaProcess process;
	
	public TransPropiaController (TransCuentaPropiaProcess process) {
		this.process = process;
	}
	
	@PostMapping("${config.endpoints.trans-propia.url}")
	public Envelope<Status, RespTransactionPojo> saveOwnTransfer(
			@RequestBody ReqTransactionPojo input){
		return process.saveTransCuentaPropia(input);
	}
}
 