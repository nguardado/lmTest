package com.life.process.trapropia;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.life.data.trapropia.ITransCuentaPropiaData;
import com.life.data.validateown.IValidateOwnAccountData;
import com.life.pojo.envelope.Envelope;
import com.life.pojo.envelope.Message;
import com.life.pojo.envelope.Status;
import com.life.pojo.transactions.ReqTransactionPojo;
import com.life.pojo.transactions.RespTransactionPojo;
import com.life.pojo.transactions.ValidateAccountPojo;
import com.life.utils.ResponseCodes;
import com.life.utils.ResponseMsg;

@Service("TransPropiaProcess")
public class TransCuentaPropiaProcess implements ITransCuentaPropiaProcess{
	private IValidateOwnAccountData validateData;
	private ITransCuentaPropiaData sendData;
	private Logger log;
	
	public TransCuentaPropiaProcess(@Qualifier("BeanDataValidateAccount") IValidateOwnAccountData validateData,
			@Qualifier("BeanDataTransPropia") ITransCuentaPropiaData sendData) {
		this.validateData = validateData;
		this.sendData = sendData;
		this.log =  LoggerFactory.getLogger("com.lifebank.logger");
	}
	
	@Override
	public Envelope<Status, RespTransactionPojo> saveTransCuentaPropia(ReqTransactionPojo value) {
		Status s = new Status();
		RespTransactionPojo response = new RespTransactionPojo();
		ValidateAccountPojo valAcc = validateData.validateOwnAccount(value.getOrigingAccount(), value.getDestAccount(), value.getAmount());
		if(valAcc != null && valAcc.getStatus()) {
			response = sendData.transCuentaPropia(value, valAcc.getClientCode());
			if(response.getTransactionCode() != null) {
				s.setCode(ResponseCodes.SUCCESS);
				s.setResult(ResponseMsg.SUCCESS);				
			} else {
				s.setCode(ResponseCodes.PROCESSERROR);
				s.setResult(ResponseMsg.PROCESSERROR);
				log.error("Se produjo un error al depositar en al cuenta origen {} y destino {}", value.getOrigingAccount(), value.getDestAccount());
			}
		} else {
			s.setCode(ResponseCodes.NOMATCH);
			s.setResult(ResponseMsg.NOMATCH);
			log.error("Se produjo un error al depositar en al cuenta origen {} y destino {}", value.getOrigingAccount(), value.getDestAccount());
		}
			
		return new Message<>(s, response);
	}

}
