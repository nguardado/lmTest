package com.life.controller;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.life.pojo.Productos;
import com.life.pojo.envelope.Envelope;
import com.life.pojo.envelope.Status;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
@ActiveProfiles("testing")
public class ProductTest extends Mockito{
	static {
		com.life.Initialize.initializeVariables();
    }
	
	@Autowired
	private ProductController controller;
	
	@Test
	public void getProducts() {
		Envelope<Status, Productos> response = controller.getAllProducts("AE123456");
		Assert.assertEquals("200", response.getHeader().getCode());
		Assert.assertEquals(2, response.getBody().getCreditCars().size());
	}
	
	@Test
	public void getWrongUser() {
		Envelope<Status, Productos> response = controller.getAllProducts("AE123433");
		Assert.assertEquals("400", response.getHeader().getCode());	
	}
	
}
