package com.life.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.life.entity.CliClient;
import com.life.entity.LoaLoanClient;

public interface LoanRepository extends CrudRepository<LoaLoanClient, CliClient>{
	public List<LoaLoanClient> findByCliClient(CliClient cliClient);
}
