package com.life.data.rep.loans;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.life.pojo.rep.loans.RepLoans;
import com.life.pojo.rep.transaction.Transactions;

@Service("RepLoansStatic")
public class RepLoansStatic implements IRepLoansData{
	private RepLoans loans;
	private List<Transactions> lstTransactions;
	private Logger log = LoggerFactory.getLogger("com.lifebank.logger");
	private Map<String, RepLoans> mapLoans;
	
	@Value("${config.date-format}")
	String normalDate;
	
	public RepLoansStatic() {
				
		mapLoans = new HashMap<>();		 
		loans = new RepLoans();					
	}
	
	@Override
	public RepLoans getLoansReport(String idAccount, String startDate, String endDate) {
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat(normalDate, Locale.ENGLISH);
			Date newDate = dateFormat.parse("2019-04-13");
			lstTransactions = new ArrayList<>();
			lstTransactions.add(new Transactions("152535", newDate, "Loan payment", 100d));
			lstTransactions.add(new Transactions("152688", newDate, "Loan payment", 125.43d));
			loans.setId("AE1235454");
			loans.setStartDate(newDate);
			loans.setEndDate(newDate);
			loans.setTotal(7500d);
			loans.setDebt(3250.43);
			loans.setInterestRate(5.25);
			loans.setInteresAmount(0.0);
			loans.setTransactions(lstTransactions);
			mapLoans.put("55223366", loans);
		} catch (ParseException e) {
			log.error("Error en el formato de fecha " + e.getMessage(), e);			
		}	
		if(mapLoans.containsKey(idAccount))
			return mapLoans.get(idAccount);
		else
			return new RepLoans();		
	}
}
