package com.life.data.account;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.life.pojo.account.AccountInfo;

@Service("AccountStatic")
public class AccountDataStatic implements IAccountData{
	private List<AccountInfo> lstAccount;
	private Map<String, List<AccountInfo>> mapAccounts;
	
	public AccountDataStatic() {
		mapAccounts = new HashMap<>();
		lstAccount = new ArrayList<>();
		
		lstAccount.add(new AccountInfo("COA0001", "Cuenta de Ahorros"));
		mapAccounts.put("AE123456", lstAccount);
		
		lstAccount = new ArrayList<>();
		lstAccount.add(new AccountInfo("COP0001", "Cuenta Planillera"));
		mapAccounts.put("AE123455", lstAccount);
	}
	@Override
	public List<AccountInfo> getAllAcounts(String idCliente) {
		if(mapAccounts.containsKey(idCliente))
			return mapAccounts.get(idCliente);
		else
			return lstAccount = new ArrayList<>();
	}
	
}
