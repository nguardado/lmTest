package com.life.data.creditcards;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.life.pojo.creditcard.CreditCardInfo;
import com.life.pojo.creditcard.CreditCards;

@Service("CreditCardStatic")
public class CreditCardsStatic implements ICreditCardsData{
	private List<CreditCardInfo> lstCreditCard;
	private Map<String, List<CreditCardInfo>> mapCreditds;
	
	public CreditCardsStatic() {
		mapCreditds= new HashMap<>();
		lstCreditCard = new ArrayList<>();
		lstCreditCard.add(new CreditCardInfo("T12345", "GOLD CARD"));
		lstCreditCard.add(new CreditCardInfo("T23456", "PLATINUM CARD"));
		mapCreditds.put("AE123456", lstCreditCard);
		
		lstCreditCard = new ArrayList<>();
		lstCreditCard.add(new CreditCardInfo("T12341", "GOLD CARD"));
		lstCreditCard.add(new CreditCardInfo("T23451", "PLATINUM CARD"));
		mapCreditds.put("AE123455", lstCreditCard);
	}
	
	@Override
	public List<CreditCardInfo> getAllCards(String id) {				
		if(mapCreditds.containsKey(id))
			return mapCreditds.get(id);
		else
			return lstCreditCard = new ArrayList<>();
	}

}
