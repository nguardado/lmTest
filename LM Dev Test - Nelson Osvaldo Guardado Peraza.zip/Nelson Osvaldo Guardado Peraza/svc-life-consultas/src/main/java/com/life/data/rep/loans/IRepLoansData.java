package com.life.data.rep.loans;

import com.life.pojo.rep.loans.RepLoans;

public interface IRepLoansData {
	public RepLoans getLoansReport(String idAccount, String startDate, String endDate);
}
