package com.life.process.rep.accounts;

import com.life.pojo.envelope.Envelope;
import com.life.pojo.envelope.Status;
import com.life.pojo.rep.prod.RepTypeProd;

public interface IRepAccountProcess {
	public Envelope<Status, RepTypeProd> retriveRepAccount(String idAccount, String startDate, String endDate, String prd);
}
