package com.life.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.life.entity.CcCreditCardClient;
import com.life.entity.CliClient;
import com.life.entity.LoaLoanClient;

public interface CreditCardRepository extends CrudRepository<CcCreditCardClient, CliClient>{
	public List<CcCreditCardClient> findByCliClient(CliClient cliClient);	
}
