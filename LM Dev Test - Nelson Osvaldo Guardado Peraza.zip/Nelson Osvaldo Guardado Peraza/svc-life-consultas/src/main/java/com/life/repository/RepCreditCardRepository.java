package com.life.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.life.entity.CcCreditCardClient;
import com.life.entity.TraTransactions;

public interface RepCreditCardRepository extends CrudRepository<TraTransactions, CcCreditCardClient>{
	public List<TraTransactions> findByCcCreditCardClient(CcCreditCardClient ccCreditCardClient);
}
