package com.life.process.rep.accounts;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.Period;
import java.time.YearMonth;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.life.data.rep.account.IRepAccountData;
import com.life.data.rep.creditcards.IRepCreditCardsData;
import com.life.data.rep.loans.IRepLoansData;
import com.life.pojo.envelope.Envelope;
import com.life.pojo.envelope.Message;
import com.life.pojo.envelope.Status;
import com.life.pojo.rep.account.RepAccount;
import com.life.pojo.rep.creditcard.RepCreditCards;
import com.life.pojo.rep.loans.RepLoans;
import com.life.pojo.rep.prod.RepTypeProd;
import com.life.utils.ResponseCodes;
import com.life.utils.ResponseMsg;

@Service("RepAccountProcess")
public class RepAccountProcess implements IRepAccountProcess{
	private IRepAccountData data;
	private IRepCreditCardsData creditData;
	private IRepLoansData loanData;
	private Logger log;
	
	@Value("${config.date-format}")
	String normalDate;
	
	@Value("${config.prd-account}")
	String typeAccount;
	
	@Value("${config.prd-creditcard}")
	String typeCC;
	
	@Value("${config.prd-loan}")
	String typeLoan;
	
	public RepAccountProcess (
			@Qualifier("BeanDataRepAccount") IRepAccountData data,
			@Qualifier("BeanDataRepCreditCard") IRepCreditCardsData creditData,
			@Qualifier("BeanDataRepLoans") IRepLoansData loanData) {
		this.data = data;
		this.creditData = creditData;
		this.loanData = loanData;
		this.log = LoggerFactory.getLogger("com.lifebank.logger");
	};
	
	@Override
	public Envelope<Status, RepTypeProd> retriveRepAccount(String idAccount, String startDate, String endDate, String prd) {
		Status status = new Status();		
		RepTypeProd typePrd = new RepTypeProd();
		boolean valDates = validateDates(startDate, endDate);		
		//Account Data
		if(valDates) {
			if(typeAccount.equals(prd)) {
				try {
					RepAccount account = new RepAccount();								
						account = data.getAccountReport(idAccount, startDate, endDate);
						if(account != null && account.getId() != null) {
							status.setCode(ResponseCodes.SUCCESS);
							status.setResult(ResponseMsg.SUCCESS);
							typePrd.setRepAccount(account);
						} else {
							status.setCode(ResponseCodes.FAIL);
							status.setResult(ResponseMsg.ACCOUNTNOTFOUND);
							log.info("User does'not has account: {}", idAccount);	
						}
						
					} catch (Exception e) {
					log.error("Error retreiving account: {}", idAccount);	
				}
			} 
			//creditCard Data
			else if (typeCC.equals(prd)) {
				try {
					RepCreditCards ccredit = new RepCreditCards();
					ccredit = creditData.getCreditCarsReport(idAccount, startDate, endDate);
					if(ccredit != null && ccredit.getId() != null) {
						status.setCode(ResponseCodes.SUCCESS);
						status.setResult(ResponseMsg.SUCCESS);
						typePrd.setRepCreditCard(ccredit);
					} else {
						status.setCode(ResponseCodes.FAIL);
						status.setResult(ResponseMsg.ACCOUNTNOTFOUND);
						log.info("User does'not has account: {}", idAccount);	
					}
				} catch (Exception e) {
					log.error("Error retreiving account: {}", idAccount);
				}			
			} 
			//Loans data
			else if (typeLoan.equals(prd)) {
				try {
					RepLoans loans = new RepLoans();
					loans = loanData.getLoansReport(idAccount, startDate, endDate);
					if(loans != null && loans.getId() != null) {
						status.setCode(ResponseCodes.SUCCESS);
						status.setResult(ResponseMsg.SUCCESS);
						typePrd.setRepLoan(loans);
					} else {
						status.setCode(ResponseCodes.FAIL);
						status.setResult(ResponseMsg.ACCOUNTNOTFOUND);
						log.info("User does'not has account: {}", idAccount);	
					}
				} catch (Exception e) {
					log.error("Error retreiving account: {}", idAccount);
				}
			}
		} else {
			status.setCode(ResponseCodes.FAIL);
			status.setResult(ResponseMsg.EXCEEDTIME);
		}
							
		return new Message<>(status, typePrd);
	}
	
	private Boolean validateDates(String date1, String date2) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(normalDate, Locale.ENGLISH);
		try {
			Date comp1 = dateFormat.parse(date1);
			Date comp2 = dateFormat.parse(date2);
			Long diff = ChronoUnit.DAYS.between(LocalDate.parse(date1), LocalDate.parse(date2));
			if(diff <= 90 && !comp2.before(comp1))
				return true;
			else
				return false;						
		} catch (ParseException e) {
			log.error("date no parseable {} to {}", date1, date2);
			return false;
		}								
	}
}
