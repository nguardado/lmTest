package com.life.pojo.creditcard;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CreditCards {
	private	String creditCardNumber;
	private String clientNumber;
	private Date startValidityDate;
	private Date endvalidtyDate;
	private Double availableAmount;
	private Double cardLimit;
	private Integer montlyCut;
	private Double interestAmount;
	private Date createDate;
	private Date modDate;
	private Date closeDate;
	private String creditCardStatus;
	private String description;
}
