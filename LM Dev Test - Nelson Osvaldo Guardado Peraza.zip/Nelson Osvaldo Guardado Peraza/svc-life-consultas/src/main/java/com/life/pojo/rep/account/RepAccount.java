package com.life.pojo.rep.account;

import java.util.Date;
import java.util.List;

import com.life.pojo.rep.transaction.Transactions;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class RepAccount {
	private String id;
	private Date startDate;
	private Date endDate;
	private List<Transactions> transactions;
}
