package com.life.data.loan;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.life.entity.CliClient;
import com.life.entity.LoaLoanClient;
import com.life.pojo.loan.LoanInfo;
import com.life.repository.LoanRepository;

@Service("LoanDatabase")
public class LoanDataBase implements ILoanData{
	private LoanRepository loanRepo;
	private Logger log;
	
	public LoanDataBase(LoanRepository loanRepo) {
		this.loanRepo = loanRepo;
		this.log = LoggerFactory.getLogger("com.lifebank.logger");
	}

	@Override
	public List<LoanInfo> getAllLoans(String idCliente) {
		List<LoanInfo> lstLoanInfo = null;
		LoanInfo loanInfo = null;
		try {
			CliClient cliClient = new CliClient();
			cliClient.setCliCode(idCliente);
			List<LoaLoanClient> listLoanBd = loanRepo.findByCliClient(cliClient);
			if(listLoanBd != null && !listLoanBd.isEmpty()) {
				lstLoanInfo = new ArrayList<>();
				loanInfo = new LoanInfo();
				for (LoaLoanClient item : listLoanBd) {
					loanInfo.setId(item.getLoaLoanCode());
					loanInfo.setName(item.getTloaLoanType().getTloaName());
					lstLoanInfo.add(loanInfo);
				}
			}
			
		} catch (Exception e) {
			log.error("Error in retrieve Loans from Database: {}", e.getMessage(), e);
		}
		return lstLoanInfo;
	}

}
