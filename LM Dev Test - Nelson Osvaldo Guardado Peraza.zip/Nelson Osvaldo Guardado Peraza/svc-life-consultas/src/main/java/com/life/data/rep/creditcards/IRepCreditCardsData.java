package com.life.data.rep.creditcards;

import com.life.pojo.rep.creditcard.RepCreditCards;

public interface IRepCreditCardsData {
	public RepCreditCards getCreditCarsReport(String idAccount, String startDate, String endDate);
}
