package com.life.utils;

public class ResponseCodes {
	public static final String SUCCESS="200";
	public static final String FAIL="400";
}
