package com.life.pojo.rep.creditcard;

import java.util.Date;
import java.util.List;

import com.life.pojo.rep.transaction.Transactions;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class RepCreditCards {
	private String id;
	private Date startDate;
	private Date endDate;
	private Double limit;
	private Double available;
	private Double interestRate;
	private Double interestAmount;
	private Double monthlyCut;
	private List<Transactions> transactions;
}
