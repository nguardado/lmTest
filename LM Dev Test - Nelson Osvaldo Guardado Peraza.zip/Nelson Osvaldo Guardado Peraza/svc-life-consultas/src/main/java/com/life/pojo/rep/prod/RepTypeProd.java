package com.life.pojo.rep.prod;

import com.life.pojo.rep.account.RepAccount;
import com.life.pojo.rep.creditcard.RepCreditCards;
import com.life.pojo.rep.loans.RepLoans;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class RepTypeProd {	
	private RepAccount repAccount;
	private RepCreditCards repCreditCard;
	private RepLoans repLoan;
}
