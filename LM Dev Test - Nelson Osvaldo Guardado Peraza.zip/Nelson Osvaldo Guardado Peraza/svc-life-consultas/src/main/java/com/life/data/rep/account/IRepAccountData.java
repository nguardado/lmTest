package com.life.data.rep.account;

import com.life.pojo.rep.account.RepAccount;

public interface IRepAccountData {
	public RepAccount getAccountReport(String idAccount, String startDate, String endDate);
}
