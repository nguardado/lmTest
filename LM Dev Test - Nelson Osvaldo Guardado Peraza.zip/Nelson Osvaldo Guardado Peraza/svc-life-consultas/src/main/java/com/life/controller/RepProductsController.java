package com.life.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.life.pojo.envelope.Envelope;
import com.life.pojo.envelope.Status;
import com.life.pojo.rep.prod.RepTypeProd;
import com.life.process.rep.accounts.IRepAccountProcess;
import com.life.process.rep.accounts.RepAccountProcess;

@RestController
public class RepProductsController {
	private IRepAccountProcess accProcess;
	
	public RepProductsController (RepAccountProcess accProcess) {
		this.accProcess = accProcess;
	}
	
	/*@GetMapping("${config.endpoints.rep-account.url}")	
	public Envelope<Status, RepTypeProd> getRepAccount(
			@PathVariable ("accountID") String accountID,
			@RequestParam("start") String start,
			@RequestParam("end") String end,
			@RequestParam("prd") String prd){
		return accProcess.retriveRepAccount(accountID, start, end, prd);
	}*/
	
	@GetMapping("${config.endpoints.rep-account.url}")	
	public Envelope<Status, RepTypeProd> getRepAccount(			
			@PathVariable ("accountID") String accountID,
			@PathVariable("start") String start,
			@PathVariable("end") String end,
			@PathVariable("prd") String prd){
		return accProcess.retriveRepAccount(accountID, start, end, prd);
	}
	

}
