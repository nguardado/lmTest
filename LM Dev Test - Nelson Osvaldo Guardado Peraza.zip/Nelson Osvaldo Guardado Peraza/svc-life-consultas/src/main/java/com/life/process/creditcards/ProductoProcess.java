package com.life.process.creditcards;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.life.data.account.IAccountData;
import com.life.data.creditcards.ICreditCardsData;
import com.life.data.loan.ILoanData;
import com.life.pojo.Productos;
import com.life.pojo.account.AccountInfo;
import com.life.pojo.creditcard.CreditCardInfo;
import com.life.pojo.envelope.Envelope;
import com.life.pojo.envelope.Message;
import com.life.pojo.envelope.Status;
import com.life.pojo.loan.ListLoan;
import com.life.pojo.loan.LoanInfo;
import com.life.utils.ResponseCodes;
import com.life.utils.ResponseMsg;

@Service("ProductProcess")
public class ProductoProcess implements IProductProcess{
	private ICreditCardsData data;
	private IAccountData dataAcount;
	private ILoanData dataLoan;	
	private Logger log;
	
	public ProductoProcess(
			@Qualifier("BeanDataCreditCard") ICreditCardsData data,
			@Qualifier("BeanDataAccount") IAccountData dataAcount,
			@Qualifier("BeanDataLoan") ILoanData dataLoan){
		this.data = data;		
		this.dataAcount = dataAcount;
		this.dataLoan = dataLoan;
		this.log = LoggerFactory.getLogger("com.lifebank.logger");
	};
	
	@Override
	public Envelope<Status, Productos> retriveProducts(String idClient) {
		Status status = new Status();
		Productos producto = new Productos();
		List<CreditCardInfo> creditCardinfo = new ArrayList<>();
		List<AccountInfo> accountInfo = new ArrayList<>();		
		List<LoanInfo> loanInfo = new ArrayList<>();
		ListLoan lstloan = new ListLoan();
		List<CreditCardInfo> prdCreditCard = data.getAllCards(idClient);
		try {
			if(prdCreditCard != null && !prdCreditCard.isEmpty()) {
				creditCardinfo.addAll(prdCreditCard);				
				producto.setCreditCars(creditCardinfo);				
			} else
				log.info("Error no matching creditcards for user: {}", idClient);				
			
		} catch (Exception e) {
			log.error("Error finding creditcards for user: {}", idClient);			
		}
		
		List<AccountInfo> prdAccount = dataAcount.getAllAcounts(idClient);
		try {
			if(prdAccount != null && !prdAccount.isEmpty()) {				
					accountInfo.addAll(prdAccount);													 			
					producto.setPersonal(accountInfo);								
			} else 
				log.info("Error no matching accounts for user: {}", idClient);
			
		} catch (Exception e) {
			log.error("Error finding accounts for user: {}", idClient);	
		}
		
		List<LoanInfo> prdLoan = dataLoan.getAllLoans(idClient);
		try {
			if(prdLoan != null && !prdLoan.isEmpty()) {								
					loanInfo.addAll(prdLoan);	
					lstloan.setLoan(loanInfo);
					producto.setAccounts(lstloan);								
			} else {
				log.info("Error no matching accounts for user: {}", idClient);				
			}
			
		} catch (Exception e) {
			log.error("Error finding accounts for user: {}", idClient);	
		}
		
		if(producto.getAccounts() != null && producto.getCreditCars().isEmpty() && producto.getPersonal().isEmpty()) {
			status.setCode(ResponseCodes.FAIL);
			status.setResult(ResponseMsg.FAIL);
		} else {
			status.setCode(ResponseCodes.SUCCESS);
			status.setResult(ResponseMsg.SUCCESS);			
		}
		
		return new Message<>(status, producto);
	}

}
