package com.life.data.account;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.life.entity.AccAccount;
import com.life.entity.CliClient;
import com.life.pojo.account.AccountInfo;
import com.life.repository.AccountRepository;

@Service("AccountDataBase")
public class AccountDataBase implements IAccountData{
	private AccountRepository accontRepo;
	private Logger log;
	
	public AccountDataBase (AccountRepository accountRepo) {
		this.accontRepo = accountRepo;
		this.log = LoggerFactory.getLogger("com.lifebank.logger");
	}
	
	@Override
	public List<AccountInfo> getAllAcounts(String idCliente) {
		List<AccountInfo> lstAccount = null;
		AccountInfo infoAcc = null;
		try {
			CliClient cliClient = new CliClient();
			cliClient.setCliCode(idCliente);
			List<AccAccount> lstAccountBd = accontRepo.findByCliClient(cliClient);			
			if(lstAccountBd != null && !lstAccountBd.isEmpty()) {
				lstAccount = new ArrayList<>();				
				for (AccAccount item : lstAccountBd) {
					infoAcc = new AccountInfo();
					infoAcc.setId(item.getAccCodeAccount());
					infoAcc.setName(item.getTcueTypeAccount().getTcueName());
					lstAccount.add(infoAcc);
				}
			}
			
		} catch (Exception e) {
			log.error("Error in retrieve Accounts from Database: {}", e.getMessage(), e);
		}
		
		return lstAccount;
	}

}
