package com.life.data.loan;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.life.pojo.loan.LoanInfo;

@Service("LoanStatic")
public class LoanDataStatic implements ILoanData{
	private List<LoanInfo> lstLoan;
	private Map<String, List<LoanInfo>> mapLoans;
	
	public LoanDataStatic () {
		mapLoans = new HashMap<>();		
		lstLoan = new ArrayList<>();
		lstLoan.add(new LoanInfo("LAP0001", "Prestamo Personal"));
		lstLoan.add(new LoanInfo("LAM0001", "Prestamo Mipes"));
		mapLoans.put("AE123456", lstLoan);
		
		lstLoan = new ArrayList<>();
		lstLoan.add(new LoanInfo("LAC0001", "Prestamo Carro"));
		lstLoan.add(new LoanInfo("LAM0001", "Prestamo Mipes"));
		mapLoans.put("AE123455", lstLoan);
	}

	@Override
	public List<LoanInfo> getAllLoans(String idClient) {			
		if(mapLoans.containsKey(idClient))
			return mapLoans.get(idClient);
		else
			return lstLoan = new ArrayList<>();
	}
}
