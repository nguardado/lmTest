package com.life.data.rep.loans;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.life.entity.LoaLoanClient;
import com.life.entity.TraTransactions;
import com.life.pojo.rep.loans.RepLoans;
import com.life.pojo.rep.transaction.Transactions;
import com.life.repository.RepLoanRepository;

@Service("RepLoanDataBase")
public class RepLoansDataBase implements IRepLoansData{
	private RepLoanRepository repo;
	private Logger log;
	
	@Value("${config.date-format}")
	String normalDate;
	
	public RepLoansDataBase(RepLoanRepository repo) {
		this.repo = repo;
		this.log = LoggerFactory.getLogger("com.lifebank.logger");
	}
	
	@Override
	public RepLoans getLoansReport(String idAccount, String startDate, String endDate) {
		RepLoans repLoans = new RepLoans();
		List<TraTransactions> lstTransactions = new ArrayList<>();
		
		try {
			LoaLoanClient loaClient = new LoaLoanClient();
			loaClient.setLoaLoanCode(idAccount);
			SimpleDateFormat dateFormat = new SimpleDateFormat(normalDate, Locale.ENGLISH);
			lstTransactions = repo.findByLoaLoanClient(loaClient);
			if(lstTransactions != null && !lstTransactions.isEmpty()) {
				List<Transactions> lstTra =  new ArrayList<>();
				for (TraTransactions items : lstTransactions) {
					Transactions tran = new Transactions();
					tran.setId(items.getId().getTraTransactionType() + items.getId().getTraProceedDate());
					tran.setAmount(items.getTraAmount().doubleValue());
					tran.setDate(items.getTraRegisterDate());
					tran.setDescription(items.getTraTransactionDescription());
					lstTra.add(tran);
				}
				repLoans.setTransactions(lstTra);
				repLoans.setId(lstTransactions.get(0).getTraClientCode());
				repLoans.setDebt(lstTransactions.get(0).getLoaLoanClient().getLoaLoanRemainingDebt().doubleValue());
				repLoans.setTotal(lstTransactions.get(0).getLoaLoanClient().getLoaLoanTotalDebt().doubleValue());
				repLoans.setInterestRate(lstTransactions.get(0).getLoaLoanClient().getTloaLoanType().getTloaInteresRate().doubleValue() * 100);
				repLoans.setInteresAmount(lstTransactions.get(0).getLoaLoanClient().getLoaLoanInterestAmount().doubleValue());
				repLoans.setStartDate(dateFormat.parse(startDate));
				repLoans.setEndDate(dateFormat.parse(endDate));	
			}
		} catch (Exception e) {
			log.error("Not account Found in retrieve Transactions from Database  number: {}", idAccount);
		}
		return repLoans;
	}

}
