package com.life.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.life.entity.LoaLoanClient;
import com.life.entity.TraTransactions;

public interface RepLoanRepository extends CrudRepository<TraTransactions, LoaLoanClient>{
	public List<TraTransactions> findByLoaLoanClient(LoaLoanClient loaLoanClient);
}
