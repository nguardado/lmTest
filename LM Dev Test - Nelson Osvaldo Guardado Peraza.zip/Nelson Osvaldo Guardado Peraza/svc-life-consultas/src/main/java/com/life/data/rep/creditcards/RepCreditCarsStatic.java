package com.life.data.rep.creditcards;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.life.pojo.rep.creditcard.RepCreditCards;
import com.life.pojo.rep.transaction.Transactions;

@Service("RepCreditCardStatic")
public class RepCreditCarsStatic implements IRepCreditCardsData{
	private RepCreditCards creditCards;
	private List<Transactions> lstTransactions;
	private Logger log = LoggerFactory.getLogger("com.lifebank.logger");
	private Map<String, RepCreditCards> mapCredit;
	
	@Value("${config.date-format}")
	String normalDate;
	
	public RepCreditCarsStatic() {				
		mapCredit = new HashMap<>();			
		creditCards = new RepCreditCards();					
	}
	
	@Override
	public RepCreditCards getCreditCarsReport(String idAccount, String startDate, String endDate) {
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat(normalDate, Locale.ENGLISH);
			Date newDate = dateFormat.parse("2019-04-13");
			lstTransactions = new ArrayList<>();
			lstTransactions.add(new Transactions("152535", newDate, "Loan payment", 100d));
			lstTransactions.add(new Transactions("152688", newDate, "Loan payment", 125.43d));
			creditCards.setId("AE1235454");
			creditCards.setStartDate(newDate);
			creditCards.setEndDate(newDate);
			creditCards.setLimit(4500.00);
			creditCards.setAvailable(3262.15);
			creditCards.setInterestRate(5.25);
			creditCards.setInterestAmount(0.0);
			creditCards.setTransactions(lstTransactions);
			creditCards.setMonthlyCut(18d);		
			
			mapCredit.put("55223366", creditCards);
		} catch (ParseException e) {
			log.error("Error en el formato de fecha " + e.getMessage(), e);			
		}
		
		if(mapCredit.containsKey(idAccount))
			return mapCredit.get(idAccount);
		else
			return new RepCreditCards();		
	}
}
