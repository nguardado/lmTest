package com.life.pojo.rep.loans;

import java.util.Date;
import java.util.List;

import com.life.pojo.rep.transaction.Transactions;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class RepLoans {
	private String id;
	private Date startDate;
	private Date endDate;
	private Double total;
	private Double debt;
	private Double interestRate;
	private Double interesAmount;
	private List<Transactions> transactions;
}
