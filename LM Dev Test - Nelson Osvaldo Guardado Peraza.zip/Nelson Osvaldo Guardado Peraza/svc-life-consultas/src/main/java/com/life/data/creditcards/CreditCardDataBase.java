package com.life.data.creditcards;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.life.entity.CcCreditCardClient;
import com.life.entity.CliClient;
import com.life.pojo.creditcard.CreditCardInfo;
import com.life.repository.CreditCardRepository;

@Service("CreditCardDatabase")
public class CreditCardDataBase implements ICreditCardsData{
	private CreditCardRepository cardRepo;
	private Logger log;
	
	public CreditCardDataBase(CreditCardRepository cardRepo) {
		this.cardRepo = cardRepo;
		this.log = LoggerFactory.getLogger("com.lifebank.logger");
	}
	
	@Override
	public List<CreditCardInfo> getAllCards(String id) {
		List<CreditCardInfo> lstCards = null;		
		CreditCardInfo info = new CreditCardInfo();
		try {
			CliClient client = new CliClient();
			client.setCliCode(id);
			List<CcCreditCardClient> lstCardsBd = cardRepo.findByCliClient(client);
			if(lstCardsBd !=null && !lstCardsBd.isEmpty()) {
				lstCards = new ArrayList<>();
				for (CcCreditCardClient item : lstCardsBd) {
					info.setId(item.getCcCreditCardNumber());
					info.setName(item.getTtaCreditCardType().getTtaName());	
					lstCards.add(info);
				}
			}
		} catch (Exception e) {
			log.error("Error in retrieve CreditCards from Database: {}", e.getMessage(), e);
		}
		return lstCards;
	}

}
