package com.life.pojo.account;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Accounts {
	private String code_account;
	private String client_code;	
	private String type_acount;
	private Double amount;
	private String status;
	private Date create_date;
	private Date mod_date;
	private Date close_date;
	private String description;
}
 