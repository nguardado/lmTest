package com.life.process.creditcards;

import com.life.pojo.Productos;
import com.life.pojo.envelope.Envelope;
import com.life.pojo.envelope.Status;

public interface IProductProcess {
	public Envelope<Status, Productos> retriveProducts(String idClient);
}
