package com.life.pojo;

public class ProductDetails {

}
