package com.life.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.life.pojo.Productos;
import com.life.pojo.envelope.Envelope;
import com.life.pojo.envelope.Status;
import com.life.process.creditcards.IProductProcess;
import com.life.process.creditcards.ProductoProcess;

@RestController
public class ProductController {
	private IProductProcess process;
	
	public ProductController (ProductoProcess process) {
		this.process = process;		
	}
	
	@GetMapping("${config.endpoints.products.get-products-info}")
	public Envelope<Status, Productos> getAllProducts(
			@PathVariable("idCliente") String idCliente){
		return process.retriveProducts(idCliente);
	}
}
