package com.life.data.loan;

import java.util.List;

import com.life.pojo.loan.LoanInfo;

public interface ILoanData {
	public List<LoanInfo> getAllLoans (String idCliente);
}
