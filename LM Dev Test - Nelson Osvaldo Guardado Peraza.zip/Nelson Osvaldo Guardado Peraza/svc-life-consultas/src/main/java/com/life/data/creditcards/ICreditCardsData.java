package com.life.data.creditcards;

import java.util.List;

import com.life.pojo.creditcard.CreditCardInfo;

public interface ICreditCardsData {
	public List<CreditCardInfo> getAllCards(String id);
}
