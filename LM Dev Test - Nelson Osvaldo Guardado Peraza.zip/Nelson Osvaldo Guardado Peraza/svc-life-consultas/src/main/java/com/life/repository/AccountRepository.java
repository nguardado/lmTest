package com.life.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.life.entity.AccAccount;
import com.life.entity.CliClient;

public interface AccountRepository extends CrudRepository<AccAccount, CliClient>{
	public List<AccAccount> findByCliClient(CliClient cliClient);
}
