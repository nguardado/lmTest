package com.life.data.rep.account;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.life.pojo.rep.account.RepAccount;
import com.life.pojo.rep.transaction.Transactions;

@Service("RepAccountStatic")
public class RepAccountStatic implements IRepAccountData{
	private RepAccount account;
	private List<Transactions> lstTransactions;
	private Logger log = LoggerFactory.getLogger("com.lifebank.logger");
	private Map<String, RepAccount> mapAccounts;
	
	@Value("${config.date-format}")
	String normalDate;
	
	public RepAccountStatic() {				
		mapAccounts = new HashMap<>();		 
		account = new RepAccount();												
	}
	
	@Override
	public RepAccount getAccountReport(String idAccount, String startDate, String endDate) {
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat(normalDate, Locale.ENGLISH);			
			Date newDate = dateFormat.parse("2019-04-13");
			lstTransactions = new ArrayList<>();
			lstTransactions.add(new Transactions("152535", newDate, "Credit card payment", 100d));
			lstTransactions.add(new Transactions("152688", newDate, "Amazon payments", 125.43d));
			account.setId("AE1235454");
			account.setStartDate(newDate);
			account.setEndDate(newDate);
			account.setTransactions(lstTransactions);
			mapAccounts.put("55223366", account);
		} catch (ParseException e) {
			log.error("Error en el formato de fecha " + e.getMessage(), e);
			e.printStackTrace();
		}
		if(mapAccounts.containsKey(idAccount))
			return mapAccounts.get(idAccount);
		else
			return new RepAccount();		
	}
}
