package com.life.utils;

public class ResponseMsg {
	public static final String SUCCESS="Success";
	public static final String FAIL="Fallido";
	public static final String NOTCARD="Cliente no tiene tarjetas";
	public static final String EXCEEDTIME="Las fechas son mayores a 3 meses";
	public static final String ACCOUNTNOTFOUND = "Cuenta no encontrada";
	
}
