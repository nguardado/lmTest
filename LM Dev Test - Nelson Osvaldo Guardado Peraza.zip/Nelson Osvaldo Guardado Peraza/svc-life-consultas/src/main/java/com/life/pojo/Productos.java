package com.life.pojo;

import java.util.ArrayList;
import java.util.List;

import com.life.pojo.account.AccountInfo;
import com.life.pojo.creditcard.CreditCardInfo;
import com.life.pojo.loan.ListLoan;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Productos {	
	private ListLoan accounts = new ListLoan();	
	private List<CreditCardInfo> creditCars = new ArrayList<>();
	private List<AccountInfo> personal = new ArrayList<>();
}
