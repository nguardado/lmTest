package com.life.pojo.loan;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Loan {
	private String loanCode;
	private String loanClientCode;
	private Double loanTotalDebt;
	private Double loanRemDebt;
	private Double loanIntAmount;
	private Date createDate;
	private Date endDate;
	private Date modDate;
	private Date closeDate;
	private String description;
}
