package com.life.data.rep.creditcards;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.life.entity.CcCreditCardClient;
import com.life.entity.TraTransactions;
import com.life.pojo.rep.creditcard.RepCreditCards;
import com.life.pojo.rep.transaction.Transactions;
import com.life.repository.RepCreditCardRepository;

@Service("RepCreditCardDataBase")
public class RepCreditCardDataBase implements IRepCreditCardsData{
	private RepCreditCardRepository repo;
	private Logger log;
	
	@Value("${config.date-format}")
	String normalDate;
	
	public RepCreditCardDataBase (RepCreditCardRepository repo) {
		this.repo = repo;
		this.log = LoggerFactory.getLogger("com.lifebank.logger");
	}
	
	@Override
	public RepCreditCards getCreditCarsReport(String idAccount, String startDate, String endDate) {
		RepCreditCards creditCard = new RepCreditCards();
		List<TraTransactions> lstTransactions = new ArrayList<>();		
		try {
			CcCreditCardClient cred = new CcCreditCardClient();
			cred.setCcCreditCardNumber(idAccount);
			SimpleDateFormat dateFormat = new SimpleDateFormat(normalDate, Locale.ENGLISH);
			lstTransactions = repo.findByCcCreditCardClient(cred);
			if(lstTransactions != null && !lstTransactions.isEmpty()) {
				List<Transactions> lstTra =  new ArrayList<>();
				for (TraTransactions items : lstTransactions) {
					Transactions tran = new Transactions();
					tran.setId(items.getId().getTraTransactionType() + items.getId().getTraProceedDate());
					tran.setAmount(items.getTraAmount().doubleValue());
					tran.setDate(items.getTraRegisterDate());
					tran.setDescription(items.getTraTransactionDescription());
					lstTra.add(tran);
				}
				creditCard.setTransactions(lstTra);
				creditCard.setId(lstTransactions.get(0).getTraClientCode());
				creditCard.setAvailable(lstTransactions.get(0).getCcCreditCardClient().getCcAvailableAmount().doubleValue());
				creditCard.setLimit(lstTransactions.get(0).getCcCreditCardClient().getTtaCreditCardType().getTtaLimit().doubleValue());
				creditCard.setMonthlyCut(lstTransactions.get(0).getCcCreditCardClient().getCcMontlyCut().doubleValue());
				creditCard.setInterestAmount(lstTransactions.get(0).getCcCreditCardClient().getCcInterestAmount().doubleValue());
				creditCard.setStartDate(dateFormat.parse(startDate));
				creditCard.setEndDate(dateFormat.parse(endDate));								
			}
		} catch (Exception e) {
			log.error("Not account Found in retrieve Transactions from Database credit card number: {}", idAccount);
		}
		return creditCard;
	}
	

}
