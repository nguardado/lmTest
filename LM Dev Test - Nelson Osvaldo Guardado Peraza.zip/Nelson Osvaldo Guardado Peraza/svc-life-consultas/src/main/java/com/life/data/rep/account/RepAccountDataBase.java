package com.life.data.rep.account;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.life.entity.AccAccount;
import com.life.entity.TraTransactions;
import com.life.pojo.rep.account.RepAccount;
import com.life.pojo.rep.transaction.Transactions;
import com.life.repository.RepAccountRepository;

@Service("RepAccountDataBase")
public class RepAccountDataBase implements IRepAccountData{
	private RepAccountRepository repository;
	private Logger log;
	
	@Value("${config.date-format}")
	String normalDate;
	
	public RepAccountDataBase (RepAccountRepository repository) {
		this.repository = repository;
		this.log = LoggerFactory.getLogger("com.lifebank.logger");
	}
	
	@Override
	public RepAccount getAccountReport(String idAccount, String startDate, String endDate) {
		RepAccount repAccount = new RepAccount();		
		List<TraTransactions> lstTransactions = new ArrayList<>();
		try {
			AccAccount accAccount = new AccAccount();
			accAccount.setAccCodeAccount(idAccount);
			SimpleDateFormat dateFormat = new SimpleDateFormat(normalDate, Locale.ENGLISH);						
			lstTransactions = repository.findByAccAccount(accAccount);
			//lstTransactions = repository.findByTraRegisterDateBetweenAndAccAccount(dateFormat.parse(startDate), dateFormat.parse(endDate), accAccount);
			if(lstTransactions != null && !lstTransactions.isEmpty()) {
				List<Transactions> lstTran = new ArrayList<>();
				for (TraTransactions items : lstTransactions) {
					Transactions transactions = new Transactions();
					transactions.setId(items.getId().getTraTransactionType() + items.getId().getTraProceedDate());
					transactions.setDate(items.getTraRegisterDate());
					transactions.setDescription(items.getTraTransactionDescription());
					transactions.setAmount(items.getTraAmount().doubleValue());
					lstTran.add(transactions);
				}
				repAccount.setTransactions(lstTran);
				repAccount.setStartDate(dateFormat.parse(startDate));
				repAccount.setEndDate(dateFormat.parse(endDate));
				repAccount.setId(lstTransactions.get(0).getTraClientCode());
			} else {
				log.error("Not account Found in retrieve Transactions from Database id Account: {}", idAccount);
			}
			
			
		} catch (Exception e) {
			log.error("Error in retrieve Transactions from Database: {}", e.getMessage(), e);
		}
		return repAccount;
	}

}
