package com.life.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.life.entity.AccAccount;
import com.life.entity.TraTransactions;

public interface RepAccountRepository extends CrudRepository<TraTransactions, String>{
	public List<TraTransactions> findByAccAccount(AccAccount accAccount); 
	public List<TraTransactions> findByTraRegisterDateBetweenAndAccAccount(Date value, Date value2, AccAccount accAccount);
}
