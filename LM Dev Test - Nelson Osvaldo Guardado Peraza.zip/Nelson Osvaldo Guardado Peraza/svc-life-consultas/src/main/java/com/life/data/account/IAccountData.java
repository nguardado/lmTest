package com.life.data.account;

import java.util.List;

import com.life.pojo.account.AccountInfo;

public interface IAccountData {
	public List<AccountInfo> getAllAcounts(String idCliente);
}
