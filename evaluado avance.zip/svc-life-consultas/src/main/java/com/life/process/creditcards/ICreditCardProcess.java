package com.life.process.creditcards;

public class ICreditCardProcess {

}
