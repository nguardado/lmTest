package com.life.data.creditcards;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.life.pojo.CreditCards;

@Service("CashierStatic")
public class CreditCardsStatic implements ICreditCards{
	private List<CreditCards> lstCreditCard;
	
	public CreditCardsStatic() {
		lstCreditCard = new ArrayList<>();
		lstCreditCard.add(new CreditCards("T12345", "GOLD CARD"));
		lstCreditCard.add(new CreditCards("T23456", "PLATINUM CARD"));
		
	}
	@Override
	public List<CreditCards> getAllCards(String id) {
		Map<String, List<CreditCards>> mapCreditds = new HashMap<>();
		mapCreditds.put("AE123456", lstCreditCard);
		
		if(mapCreditds.containsKey(id))
			return mapCreditds.get(id);
		else
			return null;
	}

}
