package com.life.data.creditcards;

import java.util.List;

import com.life.pojo.CreditCards;

public interface ICreditCards {
	public List<CreditCards> getAllCards(String id);
}
