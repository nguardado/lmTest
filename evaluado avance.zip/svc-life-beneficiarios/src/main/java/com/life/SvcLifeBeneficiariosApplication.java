package com.life;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SvcLifeBeneficiariosApplication {

	public static void main(String[] args) {
		SpringApplication.run(SvcLifeBeneficiariosApplication.class, args);
	}

}
