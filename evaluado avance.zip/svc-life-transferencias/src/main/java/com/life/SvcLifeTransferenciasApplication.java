package com.life;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SvcLifeTransferenciasApplication {

	public static void main(String[] args) {
		SpringApplication.run(SvcLifeTransferenciasApplication.class, args);
	}

}
